package com.sravan;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.ParseException;
import java.util.HashMap;

import java.util.Map;
public class FileReading {

	public static void main(String[] args) throws ParseException {
		Map<String,Integer> filesCountPerMonth=new HashMap<>();
		String[] mName={"JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"};
		File folder=new File("E:\\eclipse and tom cat\\hibernate\\hibernate\\src\\com\\fss\\model\\");
		LinkOption[] dummyLinkOption={LinkOption.NOFOLLOW_LINKS};
		try {
			File[] fileList=folder.listFiles();
			for(File file:fileList)
			{
				Path filepath=file.toPath();
				//System.out.println(filepath);
				BasicFileAttributes bfa=Files.readAttributes(filepath, BasicFileAttributes.class, dummyLinkOption);
				//System.out.println(bfa.creationTime());
				String s=bfa.creationTime().toString();
				String[] months=s.split("-");
				if(filesCountPerMonth.containsKey(months[1]))
					filesCountPerMonth.put(months[1], filesCountPerMonth.get(months[1])+1);	
				else
					filesCountPerMonth.put(months[1],1);	
					
			}
		
			for(Map.Entry<String, Integer> e:filesCountPerMonth.entrySet())
			{
				System.out.println(mName[Integer.parseInt(e.getKey())-1]+"-"+e.getValue());
			}
			//System.out.println(months[1]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
