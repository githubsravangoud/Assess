package com.sravan;
public class Tricky_USG {
	public static class a
	{
		public static class b
		{
			static int c=1;	
		}
	}
	public static class c
	{
		public static class b
		{
			static int a=1;
			
		}
	}
	public static void main(String[] args) {
a.b.c=c.b.a;
	}

}
